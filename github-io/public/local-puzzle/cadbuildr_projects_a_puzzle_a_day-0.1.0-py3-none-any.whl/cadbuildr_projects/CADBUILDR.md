# CADbuildr

This workspace is used with **CADbuildr agent** and the CADbuildr harness.

- Implement CAD geometry with **cadbuildr.foundation** in Python.
- End runnable scripts with **show(...)** so the CADbuildr prototype viewer can render.
- Do **not** use matplotlib, raw HTML, Three.js, or WebGL to display CAD solids unless the user explicitly asked for a web visualization demo.

Progressive disclosure: read the Agent Skill under `.cadbuildr_code/skills/cadbuildr-foundation/` when you need API details.
